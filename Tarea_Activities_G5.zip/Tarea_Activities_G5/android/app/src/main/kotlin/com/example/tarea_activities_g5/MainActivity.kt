package com.example.tarea_activities_g5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
