import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Menú de Ejercicios',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MenuPage(),
    );
  }
}

class MenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menú de Ejercicios'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          ListTile(
            leading: Icon(Icons.person, color: Colors.blue),
            title: Text('Ejercicio 1: Clasificación por edad'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ClasificacionEdadPage()),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.image, color: Colors.green),
            title: Text('Ejercicio 2: Precio y descuento de camisas'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ImagenPage()),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.change_history, color: Colors.purple),
            title: Text('Ejercicio 3: Terna Pitagórica'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => TernaPitagoricaPage()),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.electrical_services, color: Colors.orange),
            title: Text('Ejercicio 4: Cálculo de consumo eléctrico'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Ejercicio4Page()),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.money, color: Colors.teal),
            title: Text('Ejercicio 5: Cálculo de sueldo mensual'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Ejercicio5Page()),
              );
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.shopping_cart, color: Colors.red),
            title: Text('Ejercicio 6: Compra de Árboles'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CompraArbolesPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class ClasificacionEdadPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController edadController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Clasificación por Edad'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: edadController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese su edad',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                String mensaje;
                int? edad = int.tryParse(edadController.text);

                if (edad == null || edad < 0) {
                  mensaje = 'Por favor, ingrese una edad válida.';
                } else if (edad <= 10) {
                  mensaje = 'NIÑO';
                } else if (edad <= 14) {
                  mensaje = 'PUBER';
                } else if (edad <= 18) {
                  mensaje = 'ADOLESCENTE';
                } else if (edad <= 25) {
                  mensaje = 'JOVEN';
                } else if (edad <= 65) {
                  mensaje = 'ADULTO';
                } else {
                  mensaje = 'ANCIANO';
                }

                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Resultado'),
                      content: Text(mensaje),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text('Clasificar'),
            ),
          ],
        ),
      ),
    );
  }
}

class ImagenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController precioController = TextEditingController();
    final TextEditingController cantidadController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 2: Precio y descuento de camisas'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: precioController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el precio de una camisa',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: cantidadController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese la cantidad de camisas',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                double? precio = double.tryParse(precioController.text);
                int? cantidad = int.tryParse(cantidadController.text);

                if (precio != null && precio > 0 && cantidad != null && cantidad > 0) {
                  double descuento = 0.0;

                  if (cantidad >= 5 && cantidad <= 10) {
                    descuento = 0.10;
                  } else if (cantidad > 10) {
                    descuento = 0.20;
                  }

                  double subtotal = precio * cantidad;
                  double totalDescuento = subtotal * descuento;
                  double total = subtotal - totalDescuento;

                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Resultado'),
                        content: Text(
                          'Subtotal: \$${subtotal.toStringAsFixed(2)}\n'
                              'Descuento: \$${totalDescuento.toStringAsFixed(2)}\n'
                              'Total a pagar: \$${total.toStringAsFixed(2)}',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Error'),
                        content: Text('Por favor, ingrese valores válidos.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}

class TernaPitagoricaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController aController = TextEditingController();
    final TextEditingController bController = TextEditingController();
    final TextEditingController cController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 3: Terna Pitagórica'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: aController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el valor de a',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: bController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el valor de b',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: cController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el valor de c',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                int? a = int.tryParse(aController.text);
                int? b = int.tryParse(bController.text);
                int? c = int.tryParse(cController.text);

                if (a != null && b != null && c != null) {
                  bool esTerna = (a * a + b * b == c * c) ||
                      (a * a + c * c == b * b) ||
                      (b * b + c * c == a * a);

                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Resultado'),
                        content: Text(esTerna
                            ? 'Es una terna pitagórica'
                            : 'No es una terna pitagórica'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Error'),
                        content: Text('Por favor, ingrese valores válidos.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: Text('Verificar'),
            ),
          ],
        ),
      ),
    );
  }
}

class Ejercicio4Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController consumoController = TextEditingController();
    const double iva = 0.12;
    const int tarifa1 = 30;
    const int tarifa2 = 35;
    const int tarifa3 = 42;

    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 4: Cálculo de consumo eléctrico'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: consumoController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el consumo en KWH',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                double? consumo = double.tryParse(consumoController.text);

                if (consumo != null && consumo >= 0) {
                  double costo;

                  if (consumo <= 50) {
                    costo = consumo * tarifa1;
                  } else if (consumo <= 100) {
                    costo = (50 * tarifa1) + ((consumo - 50) * tarifa2);
                  } else {
                    costo = (50 * tarifa1) + (50 * tarifa2) + ((consumo - 100) * tarifa3);
                  }

                  double ivaCobrado = costo * iva;
                  double total = costo + ivaCobrado;

                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Resultado'),
                        content: Text(
                          'Costo: \$${costo.toStringAsFixed(2)}\n'
                              'IVA: \$${ivaCobrado.toStringAsFixed(2)}\n'
                              'Total a pagar: \$${total.toStringAsFixed(2)}',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Error'),
                        content: Text('Por favor, ingrese valores válidos.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: Text('Calcular'),
            ),
          ],
        ),
      ),
    );
  }
}

class Ejercicio5Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController sueldoBaseController = TextEditingController();
    final TextEditingController ventasController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 5: Cálculo de sueldo mensual'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: sueldoBaseController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el sueldo base',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: ventasController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ingrese el monto de ventas',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                double? sueldoBase = double.tryParse(sueldoBaseController.text);
                double? ventas = double.tryParse(ventasController.text);

                if (sueldoBase == null || ventas == null || sueldoBase < 0 || ventas < 0) {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Error'),
                        content: Text('Por favor, ingrese valores válidos.'),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text('OK'),
                          ),
                        ],
                      );
                    },
                  );
                  return;
                }

                double comision = 0;
                if (ventas < 4000000) {
                  comision = 0;
                } else if (ventas >= 4000000 && ventas < 10000000) {
                  comision = ventas * 0.03;
                } else {
                  comision = ventas * 0.07;
                }

                double sueldoTotal = sueldoBase + comision;

                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Resultado'),
                      content: Text(
                        'El sueldo mensual es: \$${sueldoTotal.toStringAsFixed(2)}',
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text('Calcular Sueldo Mensual'),
            ),
          ],
        ),
      ),
    );
  }
}


class CompraArbolesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController paltoController = TextEditingController();
    final TextEditingController limonController = TextEditingController();
    final TextEditingController chirimoyoController = TextEditingController();
    const double IVA = 0.19;

    return Scaffold(
      appBar: AppBar(
        title: Text('Ejercicio 6: Compra de Árboles'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: paltoController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Cantidad de Paltos',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: limonController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Cantidad de Limones',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: chirimoyoController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Cantidad de Chirimoyos',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                int palto = int.tryParse(paltoController.text) ?? 0;
                int limon = int.tryParse(limonController.text) ?? 0;
                int chirimoyo = int.tryParse(chirimoyoController.text) ?? 0;

                const double precioPalto = 1200;
                const double precioLimon = 1000;
                const double precioChirimoyo = 980;

                double total = (palto * precioPalto) +
                    (limon * precioLimon) +
                    (chirimoyo * precioChirimoyo);

                total = total * (1 + IVA);

                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text('Resultado'),
                      content: Text('Total: \$${total.toStringAsFixed(2)}'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text('Calcular Total'),
            ),
          ],
        ),
      ),
    );
  }
}
